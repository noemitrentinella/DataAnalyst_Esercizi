
INSERT INTO Categoria
VALUES 
(1,'Bikes')
,(2, 'Clothing');

SELECT *
FROM Categoria;

INSERT INTO Prodotto
VALUES 
(1001, 'Bikes-100', 100.00, 1)
,(1002, 'Bikes-200', 200.50, 1)
, (1003, 'Bike Glove M', 30.70, 2)
, (1004, 'Bike Gloves', 45.99, 2);

SELECT *
FROM Prodotto;

INSERT INTO Regioni
VALUES
(5001,  'WestEurope')
, (5002,  'SouthEurope')
;

SELECT * 
FROM Regioni;

INSERT INTO Stati
VALUES
(6001, 'France', 5001)
, (6002, 'Germany', 5001)
, (6003, 'Italy', 5002)
, (6004, 'Greece', 5002);


SELECT *
FROM Stati;


INSERT INTO Vendite
VALUES
(1, 1001, 1, '30/01/2024', 5001)
, (2, 1002, 1, '30/01/2024', 5002)
, (3, 1002, 1, '01/02/2024', 5001)
, (4, 1003, 1, '02/02/2024', 5002);

SELECT *
FROM Vendite;

