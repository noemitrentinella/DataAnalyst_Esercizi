/*
1)	Verificare che i campi definiti come PK siano univoci. 
In altre parole, scrivi una query per determinare l�univocit� dei valori di ciascuna PK (una query per tabella implementata). */


SELECT IDCategoria, COUNT (*) AS Conteggio
FROM Categoria
GROUP BY IDCategoria
HAVING COUNT (*) > 1;

SELECT IDProdotto, COUNT (*) AS Conteggio
FROM Prodotto
GROUP BY IDProdotto
HAVING COUNT (*) >1;

SELECT IDRegione, COUNT (*) AS Conteggio
FROM Regioni
GROUP BY IDRegione
HAVING COUNT (*) >1;

SELECT IDStato, COUNT (*)  AS Conteggio
FROM Stati
GROUP BY IDStato
HAVING COUNT (*) >1;


SELECT IDVendita, COUNT (*) AS Conteggio
FROM Vendite
GROUP BY IDVendita
HAVING COUNT (*) > 1;


/*
2) Esporre l�elenco delle transazioni indicando nel result set il codice documento, la data, il nome del prodotto, la categoria del prodotto, 
il nome dello stato, il nome della regione di vendita e un campo booleano valorizzato in base 
alla condizione che siano passati pi� di 180 giorni dalla data vendita o meno (>180 -> True, <= 180 -> False) */




SELECT
V.IDVendita            AS CodiceDocumento 
, V.DataVendita        AS DataTransazione
, P.NomeProdotto       AS NomeProdotto
, C.NomeCategoria      AS CategoriaProdotto
, S.NomeStato          AS Stato
, R.NomeRegione        AS Regione
, datediff (Day, V.DataVendita, GETDATE  ())  AS NGiorniUltimaVendita
, CASE 
     WHEN datediff (Day, V.DataVendita, GETDATE  ())  > 180 THEN 'TRUE' 
     WHEN datediff (Day, V.DataVendita, GETDATE  ())  <= 180 THEN 'FALSE'        
  END                  AS FlagVendita
FROM Categoria AS C
INNER JOIN Prodotto AS P
   ON C.IDCategoria = P.IDCategoria
   INNER JOIN Vendite AS V
     ON P.IDProdotto = V.IDProdotto
	 INNER JOIN Regioni AS R
	   ON V.IDRegione = R.IDRegione
	   INNER JOIN Stati AS S
	     ON R.IDRegione = S.IDRegione






/* 
3) Esporre l�elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno.   */


SELECT
P.IDProdotto, YEAR(V.DataVendita)            AS AnnoVendita
, SUM (P.PrezzoUnitario * V.QuantitaVenduta) AS FatturatoAnnuo
FROM Vendite AS V
INNER JOIN Prodotto AS P
  ON V.IDProdotto = P.IDProdotto
  GROUP BY P.IDProdotto, YEAR(V.DataVendita)


  /*4)	Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente. */
  
SELECT
S.IDStato, YEAR(V.DataVendita)               AS Anno
, SUM (P.PrezzoUnitario * V.QuantitaVenduta) AS FatturatoAnnuo
FROM Prodotto AS P
INNER JOIN Vendite AS V
  ON p.IDProdotto = V.IDProdotto
  INNER JOIN Regioni AS R
   ON V.IDRegione = R.IDRegione
   INNER JOIN Stati AS S
    ON R.IDRegione = S.IDRegione
    GROUP BY S.IDStato, YEAR(V.DataVendita)
	ORDER BY YEAR(V.DataVendita) DESC, SUM (P.PrezzoUnitario * V.QuantitaVenduta)DESC


/*5)	Rispondere alla seguente domanda: qual � la categoria di articoli maggiormente richiesta dal mercato? */


SELECT
C.NomeCategoria
, COUNT (V.QuantitaVenduta)    AS QuantitaVenduta
FROM Vendite AS V
INNER JOIN Prodotto AS P
 ON V.IDProdotto = P.IDProdotto
 INNER JOIN Categoria AS C
  ON P.IDCategoria = C.IDCategoria
  GROUP BY C.NomeCategoria
  ORDER BY COUNT(V.QuantitaVenduta) DESC

--R: la categoria maggiormente richiesta dal mercato � Bikes, in quanto la quantit� venduta � maggiore rispetto alle altre categorie di articoli

/*
6)	Rispondere alla seguente domanda: quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti.*/

--APPROCCIO 1
SELECT
P.IDProdotto
, P.NomeProdotto
FROM Prodotto AS P
LEFT OUTER JOIN Vendite AS V
 ON P.IDProdotto = V.IDProdotto
 WHERE V.IDVendita IS NULL;

--APPROCCIO 2
SELECT
P.IDProdotto
, P.NomeProdotto
FROM Prodotto AS P
LEFT OUTER JOIN Vendite AS V
 ON P.IDProdotto = V.IDProdotto
 WHERE P.IDProdotto NOT IN  ( 
                               SELECT
							   P.IDProdotto
							   FROM Vendite AS V
							   INNER JOIN Prodotto AS P
							    ON V.IDProdotto = P.IDProdotto);
				


-- R: Il prodotto non venduto � 1004 - Bikes Gloves

/*7)	Esporre l�elenco dei prodotti cona la rispettiva ultima data di vendita (la data di vendita pi� recente). */

SELECT
P.IDProdotto         AS CodiceProdotto
, P.NomeProdotto     AS NomeProdotto
, V.DataVendita      AS UltimaDataVendita
 	
FROM Vendite AS V
INNER JOIN Prodotto AS P
 ON V.IDProdotto = P.IDProdotto
 WHERE V.DataVendita= (
         SELECT  MAX(DataVendita)
		 FROM Vendite AS V
		 WHERE V.IDProdotto = P.IDProdotto
		
 )


/*
8)	Creare una vista sui prodotti in modo tale da esporre una �versione denormalizzata� 
delle informazioni utili (codice prodotto, nome prodotto, nome categoria) */

CREATE VIEW VW_NT_Prodotti AS (
SELECT
P.IDProdotto
, P.NomeProdotto
, C.NomeCategoria
FROM Prodotto AS P
INNER JOIN Categoria AS C
 ON P.IDCategoria = C.IDCategoria
 );

SELECT *
FROM VW_NT_Prodotti;

/*
9)	Creare una vista per restituire una versione �denormalizzata� delle informazioni geografiche */

CREATE VIEW VW_NT_AreeGeografiche AS (

SELECT
R.IDRegione
, R.NomeRegione
, S.IDStato
, S.NomeStato
FROM Regioni AS R
INNER JOIN Stati AS S
  ON R.IDRegione = S.IDRegione
);

SELECT*
FROM VW_NT_AreeGeografiche;





