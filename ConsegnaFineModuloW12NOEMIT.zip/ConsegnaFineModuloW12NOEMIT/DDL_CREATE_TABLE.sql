


CREATE TABLE Categoria (
IDCategoria INT 
, NomeCategoria VARCHAR (250) 
, CONSTRAINT PK_Categoria PRIMARY KEY (IDCategoria)
);

CREATE TABLE Prodotto ( 
IDProdotto INT
, NomeProdotto VARCHAR (250)
, PrezzoUnitario DECIMAL (18,2)
, IDCategoria INT
, CONSTRAINT PK_Prodotto PRIMARY KEY (IDProdotto)
, CONSTRAINT FK_Prodotto_Categoria FOREIGN KEY (IDCategoria)
         REFERENCES Categoria (IDCategoria)
);

CREATE TABLE Regioni (
IDRegione INT
, NomeRegione VARCHAR (250)
, CONSTRAINT PK_Regioni PRIMARY KEY (IDRegione)
);

CREATE TABLE Stati (
IDStato INT
, NomeStato VARCHAR (250)
, IDRegione INT
, CONSTRAINT PK_Stati PRIMARY KEY (IDStato)
, CONSTRAINT FK_Stati_Regioni FOREIGN KEY (IDRegione)
    REFERENCES Regioni (IDRegione)
);

CREATE TABLE Vendite (
IDVendita INT 
, IDProdotto INT
, QuantitaVenduta INT
, DataVendita DATE
, IDRegione INT
, CONSTRAINT PK_Vendite PRIMARY KEY (IDVendita)
, CONSTRAINT FK_Vendite_Prodotto FOREIGN KEY (IDProdotto)
     REFERENCES Prodotto (IDProdotto)
, CONSTRAINT FK_Vendite_Regioni FOREIGN KEY (IDRegione)
     REFERENCES Regioni (IDRegione)
);

